# PayrexxPaymentGateway

## A Payrexx integration for Shopware

## License

The MIT License (MIT). Please see [License File](LICENSE) for more information.
